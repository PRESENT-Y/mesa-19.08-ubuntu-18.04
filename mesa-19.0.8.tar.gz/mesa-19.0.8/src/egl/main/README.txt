

Notes about the EGL library:


The EGL code here basically consists of two things:

1. An EGL API dispatcher.  This directly routes all the eglFooBar() API
   calls into driver-specific functions.

2. Fallbacks for EGL API functions.  A driver _could_ implement all the
   EGL API calls from scratch.  But in many cases, the fallbacks provided
   in libEGL (such as eglChooseConfig()) will do the job.



Bootstrapping:

When the apps calls eglInitialize() a device driver is selected and loaded
(look for _eglAddDrivers() and _eglLoadModule() in egldriver.c).

The built-in driver's entry point function is then called and given
a freshly allocated and initialised _EGLDriver, with default fallback
entrypoints set.

As part of initialization, the dispatch table in _EGLDriver->API must be
populated with all the EGL entrypoints. Some functions like
driver->API.Initialize and driver->API.Terminate _must_ be implemented
with driver-specific code (no default/fallback function is possible).


Shortly after, the driver->API.Initialize() function is executed.  Any additional
driver initialization that wasn't done in the driver entry point should be
done at this point.  Typically, this will involve setting up visual configs, etc.



Special Functions:

Certain EGL functions _must_ be implemented by the driver.  This includes:

eglCreateContext
eglCreateWindowSurface
eglCreatePixmapSurface
eglCreatePBufferSurface
eglMakeCurrent
eglSwapBuffers

Most of the EGLConfig-related functions can be implemented with the
defaults/fallbacks.  Same thing for the eglGet/Query functions.




Teardown:

When eglTerminate() is called, the driver->API.Terminate() function is
called.  The driver should clean up after itself.  eglTerminate() will
then close/unload the driver (shared library).




Subclassing:

The internal libEGL data structures such as _EGLDisplay, _EGLContext,
_EGLSurface, etc should be considered base classes from which drivers
will derive subclasses.

